document.addEventListener('DOMContentLoaded', () => {
    const statusMsg = document.getElementById('status-message');
    const selectionArea = document.getElementById('selection-area');
    const previewArea = document.getElementById('preview-area');
    const familyGenBtn = document.getElementById('family-gen-btn');
    const backBtn = document.getElementById('back-btn');
    const downloadBtn = document.getElementById('download-btn');
    const downloadFrontBtn = document.getElementById('download-front-btn');
    const cardWrap = document.getElementById('card-wrap');

    let extractedData = null;

    // 1. Initial Data Extraction
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        const isPortal = activeTab && activeTab.url && (
            activeTab.url.toLowerCase().includes('epds.telangana.gov.in') ||
            activeTab.url.toLowerCase().includes('telangana.gov.in')
        );

        if (isPortal) {
            statusMsg.innerText = "Connecting to portal...";
            chrome.tabs.sendMessage(activeTab.id, { action: "extract" }, (response) => {
                if (chrome.runtime.lastError) {
                    statusMsg.innerText = "Error: Please refresh the page and try again.";
                    console.error(chrome.runtime.lastError);
                    return;
                }

                if (response && response.details && response.details.fscNo) {
                    extractedData = response;
                    statusMsg.classList.add('hidden');
                    selectionArea.classList.remove('hidden');
                    document.getElementById('display-fsc').innerText = "FSC NO: " + response.details.fscNo;
                } else {
                    statusMsg.innerText = "Could not find Ration Card data. Please search first.";
                }
            });
        }
    });

    familyGenBtn.addEventListener('click', () => {
        selectionArea.classList.add('hidden');
        previewArea.classList.remove('hidden');
        renderTwoSidesUnified();
    });

    backBtn.addEventListener('click', () => {
        previewArea.classList.add('hidden');
        selectionArea.classList.remove('hidden');
    });

    function renderTwoSidesUnified() {
        const details = extractedData.details;
        const members = extractedData.members;

        // Filter out HOF from the list using robust normalized matching
        const normalizedHof = details.hof.trim().replace(/\s+/g, ' ').toUpperCase();
        let displayMembers = members.filter(m => {
            const normalizedName = m.name.trim().replace(/\s+/g, ' ').toUpperCase();
            return normalizedName !== normalizedHof;
        });

        // If it's a single-member family, don't hide the HOF from the list
        if (displayMembers.length === 0 && members.length > 0) {
            displayMembers = members;
        }

        // Auto-fix for up to 9 members on the first side
        const frontMax = 9;
        const frontMembers = displayMembers.slice(0, frontMax);
        const backMembers = displayMembers.length > frontMax ? displayMembers.slice(frontMax, 18) : [];

        // Create Data URL for QR (pointing to your GitHub Pages viewer with encoded data)
        // Optimized: only encode necessary data to keep QR density low and scannable
        const qrData = {
            f: details.fscNo,
            r: details.fscRefNo,
            ct: details.cardType,
            as: details.applicationStatus,
            an: details.applicationNo,
            sn: details.sksFormNo,
            on: details.officeName,
            fs: details.fpShopNo,
            h: details.hof,
            d: details.district,
            is: details.impdsStatus,
            gc: details.gasConnection,
            cn: details.consumerNo,
            ks: details.keyRegisterSlNo,
            os: details.oldRCNo,
            vt: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' }),
            m: members.map(m => m.name.substring(0, 20)) // Truncate for scannability
        };

        // Use btoa with encodeURIComponent for safe URL passing
        const encodedData = btoa(encodeURIComponent(JSON.stringify(qrData)));
        // URL is set to your new Organization repository's GH-Pages link
        const qrUrl = `https://food-security-card-telangana.github.io/fscpvc/viewer.html?d=${encodedData}`;

        // Increased size to 250 and added margin=0 for better display in the small box
        const qrImg = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrUrl)}&margin=0&ecc=L`;

        const generateSideHtml = (sideId, sideTitle, memberList) => {
            const memberRows = memberList.map(m => `<tr><td style="width:22px; color:#aaa;">${m.sno}</td><td style="font-weight:700;">${m.name}</td></tr>`).join('');

            return `
                <div id="${sideId}" class="pvc-card">
                    <div class="card-header">
                        <img src="assets/emblem_ts.svg" class="header-logo-left">
                        <div class="header-title">${sideTitle} - TELANGANA<br>(${details.district || '---'})</div>
                        <img src="assets/fsc_logo.png" class="header-logo-right">
                    </div>
                    <div class="card-content-split">
                        <div class="info-side">
                            <div><label>FSC NUMBER</label><strong class="fsc-number-val">${details.fscNo || '---'}</strong></div>
                            <div><label>REF NO</label><strong>${details.fscRefNo || '---'}</strong></div>
                            <div><label>OLD RCNO</label><strong>${details.oldRCNo || '---'}</strong></div>
                            <div class="row-layout"><label>GAS</label><strong>${details.gasConnection || '---'}</strong></div>
                            <div class="row-layout"><label>CUST NO</label><strong>${details.consumerNo || '---'}</strong></div>
                            <div class="row-layout"><label>SHOP NO</label><strong>${details.fpShopNo || '---'}</strong></div>
                        </div>
                        <div class="list-side">
                            <table class="family-table">
                                <thead><tr><th>#</th><th>FAMILY MEMBER NAME</th></tr></thead>
                                <tbody>${memberRows || '<tr><td colspan="2" style="text-align:center; padding-top:20px; color:#ccc;">NO MORE MEMBERS</td></tr>'}</tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="hof-label">HOF: ${details.hof}</div>
                        <div class="qr-box">
                            <img src="${qrImg}" width="34" height="34">
                        </div>
                    </div>
                </div>
            `;
        };

        cardWrap.innerHTML = `
            ${generateSideHtml('card-front', 'FSC Ration Card', frontMembers)}
            <div style="margin-top: 20px;">
                ${generateSideHtml('card-back', 'FSC Ration Card', backMembers)}
            </div>
        `;
    }

    downloadFrontBtn.addEventListener('click', async () => {
        const el = document.getElementById('card-front');
        const canvas = await html2canvas(el, {
            scale: 6,
            useCORS: true,
            backgroundColor: '#ffffff',
            width: 330,
            height: 210
        });
        const link = document.createElement('a');
        const safeHof = extractedData.details.hof.replace(/[^a-z0-9]/gi, '_');
        link.download = `FSC_${extractedData.details.fscNo}_${safeHof}_Front.png`;
        link.href = canvas.toContentDataURL ? canvas.toContentDataURL('image/png', 1.0) : canvas.toDataURL('image/png', 1.0);
        link.click();
    });

    downloadBtn.addEventListener('click', async () => {
        const sides = ['card-front', 'card-back'];
        for (const sideId of sides) {
            const el = document.getElementById(sideId);
            const canvas = await html2canvas(el, {
                scale: 6,
                useCORS: true,
                backgroundColor: '#ffffff',
                width: 330,
                height: 210
            });
            const link = document.createElement('a');
            const side = sideId === 'card-front' ? 'Front' : 'Back';
            const safeHof = extractedData.details.hof.replace(/[^a-z0-9]/gi, '_');
            link.download = `FSC_${extractedData.details.fscNo}_${safeHof}_${side}.png`;
            link.href = canvas.toDataURL('image/png', 1.0);
            link.click();
            await new Promise(r => setTimeout(r, 600));
        }
    });
});
